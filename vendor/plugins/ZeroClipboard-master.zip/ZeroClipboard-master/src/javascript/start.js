/*!
 * {{name}}
 * {{description}}
 * Copyright 2013 {{#each contributors}}{{name}}, {{/each}}.
 * Released under the {{license}} license
 * {{homepage}}
 * v{{version}}
 */
(function () {
  "use strict";
